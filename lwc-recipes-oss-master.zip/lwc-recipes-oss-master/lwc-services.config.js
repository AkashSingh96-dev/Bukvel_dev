module.exports = {
    resources: [{ from: 'src/resources', to: 'dist/resources' }]
};
